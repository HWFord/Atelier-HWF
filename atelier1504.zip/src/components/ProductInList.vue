<template>
  <div>
    <div class="card-img-top" alt="Cricut craft">

      <img :src="require('@/assets/img/WeddingProducts/'+productData.img)">
    </div> 
    <div class="card-body py-5">
      <h5 class="card-title">{{productData.name}}</h5>
      <p class="card-title">{{productData.price}}€</p>
    </div>
  </div>
</template>
<script>

export default {
  props: {
    productData:{
      type:Object,
      required:true
    }
  },
  routes: [
    {
      path:'/Product',
      name: 'Product',
      props: true,
      component:'Product'
     }
  ]
}
</script>
