<template>
  <div class="about">
    <h1>About Atelier HWF</h1>
  </div>
</template>
